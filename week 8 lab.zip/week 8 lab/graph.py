class Graph:
    def __init__(self, directed=False, weighted=False):
        self.graph = {}  # Initialize an empty dictionary to store the adjacency list
        self.weights = {}
        self.directed = directed
        self.weighted = weighted

    def add_vertex(self, vertex):
        if vertex not in self.graph:
            self.graph[vertex] = []  # Add a new vertex with an empty list of edges

    def add_edge(self, vertex1, vertex2, weight=0):
        if vertex1 in self.graph and vertex2 in self.graph:  # Check that vertices are present
            self.graph[vertex1].append(vertex2)
            if self.weighted:
                self.weights[(vertex1, vertex2)] = weight
            if not self.directed:  # In the case of an undirected graph, append in both directions
                self.graph[vertex2].append(vertex1)
                if self.weighted:
                    self.weights[(vertex2, vertex1)] = weight
        else:
            print("One or both vertices not found in graph.")

    def remove_edge(self, vertex1, vertex2):
        if vertex1 in self.graph and vertex2 in self.graph[vertex1]:
            self.graph[vertex1].remove(vertex2)
            self.weights.pop((vertex1, vertex2), None)
            if not self.directed:
                self.graph[vertex2].remove(vertex1)
                self.weights.pop((vertex2, vertex1), None)
        else:
            print("Edge not found.")

    def remove_vertex(self, vertex):
        if vertex in self.graph:
            # Remove all edges pointing to this vertex
            for v in self.graph:
                if vertex in self.graph[v]:
                    self.graph[v].remove(vertex)
                    self.weights.pop((v, vertex), None)
                    self.weights.pop((vertex, v), None)
            del self.graph[vertex]
        else:
            print("Vertex not found.")

    def print_graph(self):
        graph_type = "Directed" if self.directed else "Undirected"
        weight_type = "Weighted" if self.weighted else "Unweighted"
        print(f"[{graph_type}, {weight_type}]")
        for vertex in self.graph:
            if self.weighted:
                edges = [(nbr, self.weights.get((vertex, nbr), 0)) for nbr in self.graph[vertex]]
                edge_str = ", ".join(f"{nbr}(w={w})" for nbr, w in edges)
            else:
                edge_str = ", ".join(self.graph[vertex])
            print(f"  {vertex} -> [{edge_str}]")

    def bfs(self, start):
        visited = []
        queue = [start]
        seen = {start}
        while queue:
            vertex = queue.pop(0)
            visited.append(vertex)
            for nbr in self.graph[vertex]:
                if nbr not in seen:
                    seen.add(nbr)
                    queue.append(nbr)
        return visited

    def dfs(self, start):
        visited = []
        stack = [start]
        seen = set()
        while stack:
            vertex = stack.pop()
            if vertex not in seen:
                seen.add(vertex)
                visited.append(vertex)
                for nbr in reversed(self.graph[vertex]):
                    if nbr not in seen:
                        stack.append(nbr)
        return visited

    def has_undirected_cycle(self):
        visited = set()

        def dfs_cycle(current, parent):
            visited.add(current)
            for nbr in self.graph[current]:
                if nbr not in visited:
                    if dfs_cycle(nbr, current):
                        return True
                elif nbr != parent:
                    return True
            return False

        for vertex in self.graph:
            if vertex not in visited:
                if dfs_cycle(vertex, None):
                    return True
        return False
