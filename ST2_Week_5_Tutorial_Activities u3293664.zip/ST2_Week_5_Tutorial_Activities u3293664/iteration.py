import timeit

# ---------------------------------------
# RECURSIVE FUNCTIONS
# ---------------------------------------

def sum_recursive(n):
    if n == 1:
        return 1
    else:
        return n + sum_recursive(n-1)


def fibonacci_recursive(n):
    if n <= 0:
        return 0
    elif n == 1:
        return 1
    else:
        return fibonacci_recursive(n-1) + fibonacci_recursive(n-2)


def factorial_recursive(n):
    if n == 0:
        return 1
    else:
        return n * factorial_recursive(n-1)


# ---------------------------------------
# ITERATIVE FUNCTIONS
# ---------------------------------------

def sum_iterative(n):
    total = 0
    for i in range(1, n+1):
        total += i
    return total


def fibonacci_iterative(n):
    a, b = 0, 1
    for i in range(n):
        a, b = b, a + b
    return a


def factorial_iterative(n):
    result = 1
    for i in range(1, n+1):
        result *= i
    return result


# ---------------------------------------
# TEST VALUES
# ---------------------------------------

n = 20

print("Results:")
print("Sum recursive:", sum_recursive(n))
print("Sum iterative:", sum_iterative(n))

print("Fibonacci recursive:", fibonacci_recursive(10))
print("Fibonacci iterative:", fibonacci_iterative(10))

print("Factorial recursive:", factorial_recursive(10))
print("Factorial iterative:", factorial_iterative(10))


# ---------------------------------------
# TIME COMPARISON
# ---------------------------------------

print("\nTime Comparison:")

sum_rec_time = timeit.timeit(lambda: sum_recursive(n), number=1000)
sum_itr_time = timeit.timeit(lambda: sum_iterative(n), number=1000)

fib_rec_time = timeit.timeit(lambda: fibonacci_recursive(10), number=100)
fib_itr_time = timeit.timeit(lambda: fibonacci_iterative(10), number=100)

fact_rec_time = timeit.timeit(lambda: factorial_recursive(10), number=1000)
fact_itr_time = timeit.timeit(lambda: factorial_iterative(10), number=1000)

print("Sum Recursive Time:", sum_rec_time)
print("Sum Iterative Time:", sum_itr_time)

print("Fibonacci Recursive Time:", fib_rec_time)
print("Fibonacci Iterative Time:", fib_itr_time)

print("Factorial Recursive Time:", fact_rec_time)
print("Factorial Iterative Time:", fact_itr_time)
