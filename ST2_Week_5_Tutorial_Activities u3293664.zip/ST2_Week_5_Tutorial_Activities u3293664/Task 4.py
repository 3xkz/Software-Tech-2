import turtle

def koch_curve(t, order, size):
    if order == 0:
        t.forward(size)
    else:
        size = size / 3
        koch_curve(t, order-1, size)
        t.left(60)
        koch_curve(t, order-1, size)
        t.right(120)
        koch_curve(t, order-1, size)
        t.left(60)
        koch_curve(t, order-1, size)

def koch_snowflake(order, size):
    t = turtle.Turtle()
    t.speed(0)

    for i in range(3):
        koch_curve(t, order, size)
        t.right(120)

    turtle.done()

order = int(input("Enter order: "))
koch_snowflake(order, 300)
