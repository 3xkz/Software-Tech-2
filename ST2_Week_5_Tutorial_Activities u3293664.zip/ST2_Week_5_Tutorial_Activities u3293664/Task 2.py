import random
import timeit


# -------------------------
# MERGE SORT
# -------------------------
def merge_sort(array):
    if len(array) <= 1:
        return array

    mid = len(array) // 2
    left = merge_sort(array[:mid])
    right = merge_sort(array[mid:])

    return merge(left, right)


def merge(left, right):
    result = []
    i = j = 0

    while i < len(left) and j < len(right):

        if left[i] < right[j]:
            result.append(left[i])
            i += 1
        else:
            result.append(right[j])
            j += 1

    result.extend(left[i:])
    result.extend(right[j:])

    return result


# -------------------------
# INSERTION SORT
# -------------------------
def insertion_sort(arr):

    for i in range(1, len(arr)):

        key = arr[i]
        j = i - 1

        while j >= 0 and key < arr[j]:
            arr[j + 1] = arr[j]
            j -= 1

        arr[j + 1] = key

    return arr


# -------------------------
# TEST DIFFERENT DATA SIZES
# -------------------------

sizes = [100, 1000, 5000]

for size in sizes:

    data = [random.randint(1, 1000) for _ in range(size)]

    merge_time = timeit.timeit(lambda: merge_sort(data[:]), number=10)
    insertion_time = timeit.timeit(lambda: insertion_sort(data[:]), number=10)

    print("\nData size:", size)
    print("Merge Sort Time:", merge_time)
    print("Insertion Sort Time:", insertion_time)
